import{c as i,t as r,m as c,n as s,o}from"./index-Br0bKUNc.js";/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]],h=i("arrow-down-left",p);/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]],m=i("arrow-up-right",y);/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=[["path",{d:"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",key:"3c2336"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",key:"1h4pet"}],["path",{d:"M12 18V6",key:"zqpxq5"}]],g=i("badge-dollar-sign",d),a={getAll:e=>r.get("/partners",{params:e}),create:e=>r.post("/partners",e),update:(e,t)=>r.put(`/partners/${e}`,t),delete:e=>r.delete(`/partners/${e}`),getProfits:e=>r.get("/partners/profits",{params:e}),getMonthlyProfit:e=>r.get("/partners/monthly-profit",{params:e}),getStatement:(e,t)=>r.get(`/partners/${e}/statement`,{params:{year:t}}),getPayments:(e,t)=>r.get(`/partners/${e}/payments`,{params:t}),recordPayment:(e,t)=>r.post(`/partners/${e}/payments`,t),deletePayment:(e,t)=>r.delete(`/partners/${e}/payments/${t}`)};function f(e){return c({queryKey:["partners",e],queryFn:()=>a.getAll(e).then(t=>t.data)})}function P(){const e=s();return o({mutationFn:t=>a.create(t).then(n=>n.data),onSuccess:()=>e.invalidateQueries({queryKey:["partners"]})})}function q(){const e=s();return o({mutationFn:t=>a.delete(t).then(n=>n.data),onSuccess:()=>e.invalidateQueries({queryKey:["partners"]})})}function M(e,t){return c({queryKey:["partners","monthly-profit",e,t],queryFn:()=>a.getMonthlyProfit({month:e,year:t}).then(n=>n.data)})}function $(e,t){return c({queryKey:["partners",e,"statement",t],queryFn:()=>a.getStatement(e,t).then(n=>n.data),enabled:e>0})}function k(){const e=s();return o({mutationFn:({partnerId:t,data:n})=>a.recordPayment(t,n).then(u=>u.data),onSuccess:()=>{e.invalidateQueries({queryKey:["partners"]})}})}function S(){const e=s();return o({mutationFn:({partnerId:t,paymentId:n})=>a.deletePayment(t,n).then(u=>u.data),onSuccess:()=>{e.invalidateQueries({queryKey:["partners"]})}})}export{m as A,g as B,M as a,P as b,q as c,k as d,h as e,S as f,$ as g,f as u};
