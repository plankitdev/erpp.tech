function p(n,o,c){const r="\uFEFF",s=[o.join(","),...c.map(l=>l.map(i=>`"${String(i??"").replace(/"/g,'""')}"`).join(","))].join(`
`),a=new Blob([r+s],{type:"text/csv;charset=utf-8;"}),t=URL.createObjectURL(a),e=document.createElement("a");e.href=t,e.download=`${n}.csv`,e.click(),URL.revokeObjectURL(t)}export{p as e};
