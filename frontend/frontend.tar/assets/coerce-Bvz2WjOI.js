import{b as e,Z as o}from"./zod-DmYiTnrn.js";function n(r){return e(o,r)}export{n};
