import{c,T as l,j as t}from"./index-Br0bKUNc.js";import{C as s}from"./circle-dot-6Y_oKMSI.js";import{C as a}from"./circle-check-big-CRa6Sf49.js";import{T as n}from"./trending-up-CEFlgs7H.js";import{C as d}from"./clock-CROiCcwx.js";/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M4.929 4.929 19.07 19.071",key:"196cmz"}]],x=c("ban",u);/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]],h=c("circle-x",k);/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=[["rect",{x:"14",y:"3",width:"5",height:"18",rx:"1",key:"kaeet6"}],["rect",{x:"5",y:"3",width:"5",height:"18",rx:"1",key:"1wsw3u"}]],r=c("pause",_);/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],f=c("play",w);/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=[["path",{d:"m16 11 2 2 4-4",key:"9rsbq5"}],["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],b=c("user-check",C);/**
 * @license lucide-react v0.577.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"17",x2:"22",y1:"8",y2:"13",key:"3nzzx3"}],["line",{x1:"22",x2:"17",y1:"8",y2:"13",key:"1swrse"}]],z=c("user-x",v),$={active:{label:"نشط",className:"badge-success",icon:a},inactive:{label:"غير نشط",className:"badge-neutral",icon:h},pending:{label:"معلق",className:"badge-warning",icon:d},completed:{label:"مكتمل",className:"badge-success",icon:a},cancelled:{label:"ملغي",className:"badge-danger",icon:x},paid:{label:"مدفوع",className:"badge-success",icon:a},overdue:{label:"متأخر",className:"badge-danger",icon:l},partial:{label:"جزئي",className:"badge-warning",icon:s},todo:{label:"قيد الانتظار",className:"badge-neutral",icon:d},in_progress:{label:"قيد التنفيذ",className:"badge-info",icon:f},review:{label:"مراجعة",className:"badge-purple",icon:r},done:{label:"منجز",className:"badge-success",icon:a},on_hold:{label:"متوقف",className:"badge-warning",icon:r},lead:{label:"عميل محتمل",className:"badge-info",icon:n},new:{label:"جديد",className:"badge-info",icon:s},contacted:{label:"تم التواصل",className:"badge-primary",icon:b},qualified:{label:"مؤهل",className:"badge-success",icon:n},lost:{label:"مفقود",className:"badge-danger",icon:z},won:{label:"فاز",className:"badge-success",icon:a},first_contact:{label:"أول تواصل",className:"badge-warning",icon:b},proposal_sent:{label:"تم إرسال العرض",className:"badge-purple",icon:s},negotiation:{label:"تفاوض",className:"badge-warning",icon:n},contract_signed:{label:"تم التوقيع",className:"badge-success",icon:a},high:{label:"عالية",className:"badge-danger",icon:l},medium:{label:"متوسطة",className:"badge-warning",icon:s},low:{label:"منخفضة",className:"badge-info",icon:s},created:{label:"إنشاء",className:"badge-success",icon:a},updated:{label:"تعديل",className:"badge-info",icon:s},deleted:{label:"حذف",className:"badge-danger",icon:l}},q={sm:"text-[10px] px-1.5 py-0.5 gap-0.5",md:"text-xs px-2.5 py-1 gap-1",lg:"text-sm px-3 py-1.5 gap-1.5"},M={sm:10,md:12,lg:14};function S({status:o,size:i="md",label:m,showIcon:g=!0}){const e=$[o],p=(e==null?void 0:e.icon)||s,y=m||(e==null?void 0:e.label)||o,N=(e==null?void 0:e.className)||"badge-neutral";return t.jsxs("span",{className:`badge ${N} ${q[i]}`,children:[g&&t.jsx(p,{size:M[i]}),y]})}export{f as P,S,b as U};
